Sample artifacts for auditor reference.
ledger-entry.sample.json — structure of a ledger entry.
rollup.sample.json — daily Merkle rollup.
ROLLUP_ANCHORING_STATUS.sample.json — anchor proof for the rollup.
