Redacted samples for public / non-confidential use (Variant C — External trust).
Sensitive values (hashes, paths, tx_hash, timestamps) replaced with [REDACTED].
Use for "How we ensure audit integrity" page or non-tech auditor explainer.
